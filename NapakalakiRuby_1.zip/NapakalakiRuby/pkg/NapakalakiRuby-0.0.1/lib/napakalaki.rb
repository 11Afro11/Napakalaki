# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "CardDealer"
require_relative "Player"
require "singleton"
module Napakalaki
	include Singleton

	def initPlayers(names)

	end

	def nextPlayer
		
	end

	def nextTurnAllowed
		
	end

	def setEnemies
		
	end

	def getInstance
		
	end

	def developCombat

	end

	def discardVisibleTreasures
		
	end

	def discardHiddenTreasures
		
	end

	def makeTreasuresVisible(treasure)
		
	end

	def initGame(players)
		
	end

	def getCurrentPlayer
		
	end

	def getCurrentMonster
		
	end

	def nextTurn
		
	end

	def endOfGame
		
	end
end