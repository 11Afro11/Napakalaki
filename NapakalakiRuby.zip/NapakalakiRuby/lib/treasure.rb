# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module NapakalakiGame
  class Treasure
    attr_accessor :name, :bonus, :enum
    def initialize(name, bonus, enum)
      @name = name
      @bonus = bonus
      @enum = enum
    end

    def getName
      @name
    end

    def getBonus
      @bonus
    end

    def getType
      @enum
    end

  end
end
