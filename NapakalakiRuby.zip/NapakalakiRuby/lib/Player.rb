# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module NapakalakiGame

class Prize
	attr_accessor :name, :level, :dead, :canSteal, :enemy, :hiddenTreasures, :visibleTreasures, :badStuff
	def initialize(name, level, dead, canSteal, enemy, hiddenTreasures, visibleTreasures, badStuff)
		@name = name
		@level = level
		@dead = dead
		@canSteal = canSteal
		@enemy = enemy
		@hiddenTreasures = hiddenTreasures
		@visibleTreasures = visibleTreasures
		@badStuff = badStuff
	end


	def getName
		@name
	end

	def bringToLife
		@dead = false
	end

	def isDead
		@dead
	end

	def incrementLevels(lvl)
		@levels = @levels + lvl
	end

	def decrementLevels(lvl)
		@levels = @levels - lvl
	end

	def setPendingBadConsequence(bad)
		@badStuff = bad
	end

	def applyPrize(monstruo)
		@level = @level + monstruo.getPrize().getLevel()
	end

	def applyBadConsequence(monstruo)
		@level = @level - monstruo.getBc().getLevel()
	end

	def dieIfNoTreasures
		if hiddenTreasures.isEmpty() && visibleTreasures.isEmpty()
			return true 
    end
		return false
	end

	def validState
		if badStuff.isEmpty() && hiddenTreasures.size <= 4
			return true
    end
		return false
	end	

	def howManyVissibleTreasures
		return visibleTreasures.size()
	end

	def getLevel
		@level
	end

	def setEnemy(enemy)
		@enemy = enemy
	end

	def haveStolen
		@canSteal = false
	end

	def canYouGiveMeATreasure
		if !hiddenTreasures.isEmpty() || !visibleTreasures.isEmpty()
			return true
    end
		return false
	end
  end
end
